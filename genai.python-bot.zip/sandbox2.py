from nlq import answer_my_q_ed


print(answer_my_q_ed('How many artists are there?'))